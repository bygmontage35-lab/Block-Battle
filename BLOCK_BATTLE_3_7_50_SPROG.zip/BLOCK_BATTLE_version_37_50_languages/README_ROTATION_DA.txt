BLOCK BATTLE 1.7 – ROTATION

På mobil: Tryk på den faldende brik for at dreje den 90 grader med uret. Fire tryk drejer brikken 360 grader, og du kan fortsætte med at dreje.

På computer: Pil op drejer 90 grader. Fire tryk = 360 grader.

Drejeknappen virker også. Brug slip-knappen eller mellemrum til at lade brikken falde helt ned.

Rotationen prøver at flytte brikken lidt til siden eller opad, hvis den står tæt ved en væg eller gulvet. Hvis der ikke er plads, roterer brikken ikke, før der bliver plads.

Multiplayer-serveren og Android-projektet fra tidligere version er bevaret. Online test kræver fortsat en server.
