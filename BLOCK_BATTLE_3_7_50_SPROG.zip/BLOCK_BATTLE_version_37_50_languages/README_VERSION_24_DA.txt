BLOCK BATTLE GOLD EDITION 2.4 – SPEED BATTLE & LAST MAN STANDING

NYT
1. Speed Battle: vælg SPILTYPE -> SPEED BATTLE. Blokkene falder markant hurtigere.
2. Last Man Standing: Multiplayer -> vælg ROYALE 5 eller ROYALE 10.
   Spillere venter, indtil alle 5/10 har tilsluttet sig. Kampen starter 5 sekunder senere.
   Når pladen fyldes, er spilleren elimineret. Sidste aktive spiller vinder.
   Sikkerhedsgrænse: 10 minutter; derefter vinder højeste score blandt overlevende.
3. Battle Points: 40 BP pr. ryddet række i ROYALE. Maks. 500 BP.
   FRYS: 100 BP, låser modstanderens styring i 2 sekunder.
   GLID: 150 BP, gør vandrette flytninger dobbelt så store i 4 sekunder.
   En tilfældig aktiv modstander rammes. 12 sekunders pause mellem angreb.
   BP nulstilles ved hver ny kamp, kan ikke købes eller gemmes.
4. Gold Edition design, profil, dynamit, kampchat og invitationslinks bevares.

START PÅ WINDOWS
1. Udpak ZIP-filen.
2. Installer Node.js (version 20 eller nyere).
3. Åbn en terminal i den udpakkede mappe.
4. Kør: npm install
5. Kør: npm start
6. Åbn http://localhost:3000 i browseren.
7. Online test med venner kræver deployment til en offentlig server som Render.

VIGTIGE BEGRÆNSNINGER
- Online 5/10-spillerkampe er implementeret som en TESTPROTOTYPE og ikke gennemtestet
  med 5/10 rigtige enheder.
- Serveren validerer ikke endnu optjente Battle Points eller brikkernes tilstand.
  Dette skal sikres før offentlig konkurrence, så snyd undgås.
- Serveren holder rum i RAM. Genstart af serveren nulstiller aktive kampe.
- Statistik gemmes lokalt på enheden; ingen global rangliste endnu.
- Ingen rigtige køb, betalinger eller aktive annoncer.
