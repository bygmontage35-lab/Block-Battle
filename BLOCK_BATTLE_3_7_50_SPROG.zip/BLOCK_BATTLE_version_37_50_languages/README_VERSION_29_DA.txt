BLOCK BATTLE GOLD EDITION 2.9 – HURTIGANGREB I HJØRNET

NYT:
- Kompakt sort/guld angrebspanel nederst til højre, når du spiller en aktiv Last Man Standing-kamp.
- Viser Battle Points og FRYS (100 BP) og GLID (150 BP).
- Klik på angrebene direkte i panelet; de bruger de eksisterende kampregler.
- Panel kan klappes sammen for ikke at dække spillepladen.
- Skjold vises som låst, fremtidig betalt funktion. Ingen køb eller betalinger er aktiveret.
- Angreb kræver optjente BP og eksisterende cooldown; 12 sekunders ventetid mellem angreb.
- Panelet vises ikke i solospil eller uden for aktive Royale-kampe.

VIGTIGT:
- Betalingssystem, konti, sikker servervalidering af Battle Points og global rangliste er stadig prototyper.
- Hurtig adgang må ikke føre til utilsigtede køb: eventuelle fremtidige køb kræver særskilt prisvisning og bekræftelse.
- JavaScript-syntaks kontrolleret; mobil/multiplayer endnu ikke gennemtestet.

WINDOWS: Udpak, kør npm install og npm start i mappen, åbn http://localhost:3000.
