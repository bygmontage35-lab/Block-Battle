# BLOCK BATTLE GOLD EDITION 3.3 – 10 baggrundsmelodier

I Indstillinger -> Baggrundsmusik findes 10 originale, elektroniske melodier:
1. Obsidian Pulse
2. Golden Horizon
3. Neon Arena
4. Midnight Runner
5. Crystal Blocks
6. Royal Circuit
7. Arcade Starlight
8. Speed Rush
9. Victory Glow
10. Northern Lights

Tryk 'Afspil' for at starte. Vælg en anden melodi for at skifte under afspilning.
Tryk 'Sluk' for at stoppe helt. Lydstyrken kan justeres fra 0 til 60 %.

Musikken genereres lokalt i browseren med Web Audio API; ingen tredjepartssange,
ophavsretsbeskyttede indspilninger eller lydfiler anvendes. Der er ikke brug for internet
for at afspille melodierne. Melodierne er korte loops, ikke komplette indspillede sange.

Afspilning starter kun efter et brugertryk, så mobilbrowseres autoplayregler respekteres.
Valgt melodi og lydstyrke gemmes lokalt. Musikken pauser når fanen er skjult.
Ved genindlæsning starter den ikke automatisk.

BEMÆRK: Musikken er syntakskontrolleret, men endnu ikke browser-/mobiltetestet.
Reklamevideoer kan have egen lyd. Undgå overlappende lyd ved fremtidig integration.
