BLOCK BATTLE 1.8 – DELBARE INVITATIONSLINKS

1. Læg serveren online på Render (først da findes et offentligt link).
2. Åbn den offentlige spiladresse og opret en lokal profil.
3. Vælg MULTIPLAYER og OPRET KAMP.
4. Når serveren har oprettet rummet, tryk DEL INVITATIONSLINK.
5. Del linket. Modtageren åbner det i en browser, opretter profil og forsøger automatisk at deltage i kampen.
6. Linket gælder kun så længe rummet eksisterer, og kampen ikke er startet eller fuld.

Bemærk: Et invitationslink er IKKE en sikker konto eller login. Det er en genvej til en midlertidig kamp. Serveren er stadig ikke offentliggjort, og multiplayer skal testes på to enheder.
