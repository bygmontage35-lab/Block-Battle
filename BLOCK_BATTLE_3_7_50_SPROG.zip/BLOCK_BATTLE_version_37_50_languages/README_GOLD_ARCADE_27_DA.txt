BLOCK BATTLE GOLD EDITION 2.7 – GOLD ARCADE

NYT
- Spiltyper indeholder nu kun de fire forskellige spiltyper og et link til mesterudfordringen.
- Mesterudfordringen ligger i en separat visning.
- Hovedmenuen har GOLD ARCADE med 3 spilbare maskiner:
  Tombola, Klomaskine og Lykkehjulet.
- 10 GRATIS forsøg i alt pr. lokal kalenderdag, fordelt frit mellem de tre maskiner.
- Klomaskinen har en positionsskyder. Placer kloen tæt på en af tre gaver.
- Fire typer VIRTUELLE TESTPRÆMIER: Skjold, Redning, Tåge og Guldstjerne.
- Præmier vises i 'Min præmiehylde', men kan endnu IKKE bruges i kampe.
- Præmier og dagens forsøg gemmes i browserens localStorage, ikke på serveren.
- Merchandise-klub 25 kr./måned vises som et IKKE-AKTIVT koncept.

VIGTIGE BEGRÆNSNINGER
- Ingen abonnementer, betalinger, Google-login eller adresseindsamling er aktive.
- Ingen fysisk merchandise sendes; pris og levering er endnu ikke besluttet.
- Dagens 10 forsøg håndhæves kun lokalt og er ikke snydesikkert. Kræver server,
  konto og tidszonepolitik inden en offentlig lancering.
- Testpræmier er ikke de samme som købte varer og har ingen kontantværdi.
- Gratis forsøg er ikke koblet til betaling eller mulighed for kontantgevinst.
- Før merchandise-abonnement kan sælges, skal økonomi (vare + pakning + porto),
  levering, skatter, forbrugerrettigheder, opsigelse og databeskyttelse afklares.
- Google-login bekræfter en konto, men IKKE automatisk en leveringsadresse.
- Andre onlinefunktioner har stadig de kendte beta-begrænsninger.

START: Udpak ZIP. Med Node.js: npm install, npm start.
Åbn http://localhost:3000 i browseren.
