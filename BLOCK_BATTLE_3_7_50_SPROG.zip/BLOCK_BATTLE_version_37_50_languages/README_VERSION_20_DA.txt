BLOCK BATTLE 2.0 – TEMAVERDENER, TESTBUTIK OG LEVELS

NYT
- Baggrundsverdenen påvirker nu farver og glødeeffekter på velkomstskærmen.
- En ny testbutik i hovedmenuen med dynamit og ekstra række til modstanderen.
- Testmønter kan optjenes gennem onlinekampe. Der trækkes INGEN rigtige penge.
- Lokal profilprogression: 50 XP for en gennemført kamp, 150 XP ved sejr, og level stiger med XP.
- I en aktiv onlinekamp kan købte ekstra rækker sendes til modspillere.
- Købt dynamit kan rydde egen plade. Dynamit optjent ved at rydde linjer findes stadig.
- Gemmes kun på spillerens egen enhed. Sikker serverkonto mangler.

FØR RIGTIGE KØB
Google Play Billing og Apple In-App Purchase skal integreres med sikker servervalidering, en rigtig kontodatabase og beskyttelse mod snyd. Angreb og XP må ikke stole på klienten. Der skal tages stilling til aldersgrupper, fair konkurrence, refundering og annoncer. Der er ingen betalingsgateway i denne ZIP.

SERVER
npm install
npm start
Webserver: http://localhost:3000
Online deling kræver stadig deployment på Render eller tilsvarende.

TESTSTATUS
Koden er syntakskontrolleret, men ikke gennemtestet i multiplayer på fysiske telefoner.
