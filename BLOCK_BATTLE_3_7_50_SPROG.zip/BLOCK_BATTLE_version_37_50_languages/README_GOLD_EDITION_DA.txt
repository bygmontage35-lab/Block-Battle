BLOCK BATTLE 2.3 – GOLD EDITION
Spillet er 100 % gratis. Butik, testmønter, købte power-ups, ekstra liv og angreb på modstandere er fjernet.
Dynamit optjenes udelukkende ved at rydde rækker (4, 7, 10 osv.) og vises øverst på spillepladen.
Mørkt eksklusivt design med gulddetaljer. Forskellige temaer, profil-level, statistik, chat og invitationslinks er bevaret.
Der er ingen aktive reklamer eller betalingssystemer.
Progression gemmes lokalt på enheden; multiplayer kræver en online server.
Syntakstestet, ikke gennemtestet på telefoner.
