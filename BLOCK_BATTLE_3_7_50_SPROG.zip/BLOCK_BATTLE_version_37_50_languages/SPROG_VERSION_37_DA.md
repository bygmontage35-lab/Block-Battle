BLOCK BATTLE GOLD EDITION 3.7 – 50 SPROG

Der er nu 50 sprogvalg i spillerprofilen og i Indstillinger -> Sprog.
De tidligere 17 sprogvalg er bevaret, og 33 ekstra er tilføjet.
Sprogvalget gemmes i den lokale profil. Højre-til-venstre layout
aktiveres for arabisk, urdu, persisk og hebraisk.

VIGTIG BEGRÆNSNING:
Dette er første fase af internationalisering – IKKE en fuld
oversættelse af hele spillet til 50 sprog. De 33 nye sprog har
oversatte centrale navigationsord (fx Menu, Spil, Indstillinger,
Sprog og Spiltyper), men flere tekster bruger engelsk fallback,
og en del eksisterende skærme/nyere funktioner er fortsat på dansk.
Der er ikke lavet modersmåls-korrektur. Der er ikke live AI-oversættelse.

Top 50 er en praktisk bred international sprogpakke, ikke en
videnskabeligt verificeret præcis rangliste over talere.

De øvrige spilfunktioner fra 3.6 er bevaret.
JavaScript og serverkode syntakskontrolleret. Ikke browser-testet.
