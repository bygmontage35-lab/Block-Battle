BLOCK BATTLE 2.2 – DYNAMIT, VALGFRIT EKSTRA LIV OG KAMPSTATISTIK

- Dynamitindikatoren er flyttet til toppen af selve spillepladen, over canvas.
- Ekstra liv bruges IKKE automatisk: Når brættet fyldes, vælger spilleren selv at bruge et købt liv eller afslutte.
- Et liv kan kun bruges, hvis det allerede er købt i testbutikken. Ingen rigtige penge trækkes.
- Score og resterende kamptid bevares ved genoplivning. Når onlinekampens tid udløber, kan der ikke genoplives.
- Profilen har nu separat sektion for rang, spillede, vundne, tabte og uafgjorte onlinekampe samt sejrsprocent.
- Statistik er kun lokal og er ikke en global verificeret rangliste. Spillerdata og power-ups skal flyttes til sikker server før offentlig lancering.
- JavaScript er syntakskontrolleret; multiplayer og køb er endnu ikke testet på rigtige telefoner.
