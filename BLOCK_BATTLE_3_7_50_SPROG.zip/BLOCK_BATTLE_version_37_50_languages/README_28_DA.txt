BLOCK BATTLE GOLD EDITION 2.8 – MENU RETTET

- Hovedmenuens SPILTYPER åbner nu GOLD ARCADE med de tre maskiner og 10 gratis daglige forsøg.
- Hovedmenuen har igen UDFORDR VERDENSMESTEREN som selvstændig kategori.
- Den tidligere separate GOLD ARCADE-knap er erstattet af mesterknappen.
- Eksisterende arkadespil, virtuelle testpræmier og kampfunktioner bevares.
- Verdensmesteren er en fiktiv titel i spillet, ikke en dokumenteret virkelig verdensmester.
- Ingen rigtige betalinger eller abonnementer er aktive.

Start: npm install, npm start, åbn http://localhost:3000.
