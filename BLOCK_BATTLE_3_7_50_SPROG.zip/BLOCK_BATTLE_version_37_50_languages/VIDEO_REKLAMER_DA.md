# BLOCK BATTLE 3.2 – korte reklamefilm før spil

- Når spilleren vælger SPIL NU eller MULTIPLAYER fra hovedmenuen, eller starter via Spiltyper/Mester, kan en sponsorfilm vises før næste skærm.
- Maks. 10 sekunder. Spilleren kan altid trykke SPRING OVER. Når videoen slutter, fortsætter spillet straks.
- Reklamefilmen vises **ikke** oven på en allerede startet onlinekamp. Multiplayerfilmen vises før lobbyen, så alle kan starte samtidig uden reklameforsinkelse.
- Hvis der ikke er en aktiv annonce, fortsætter spillet uden ventetid.
- Annoncer mærkes tydeligt som REKLAME. Ingen videoautoplay med lyd (videoer afspilles uden lyd).
- Ingen Google Ads SDK eller annoncevisning er aktiveret. Ingen eksterne annoncekald eller tracking.

## Aktivér en egen sponsorreklame
1. Læg en MP4- eller WebM-video på højst 10 sekunder i mappen `ads/` og kopiér den til `www/ads/`.
2. Åbn `sponsor-videos.json` og `www/sponsor-videos.json`.
3. Ret fx til `{ "videos": [{ "sponsor": "Firma A", "src": "ads/firma-a.mp4", "enabled": true }] }`.
4. Brug et enkelt filnavn uden mellemrum. Gentag for flere sponsorfilm.
5. Upload opdateringerne til din server.

## Bemærk
- Film skal være dine egne eller bruges med tilladelse.
- Google AdSense understøtter ikke nødvendigvis denne slags video-preroll. En separat godkendt videoannonceløsning kan blive nødvendig.
- Før annoncer og målrettet tracking: håndtér GDPR, samtykke, aldershensyn og tydelig annoncemærkning.
- Ingen rigtige sponsorvideoer medfølger, så spillet starter direkte i standardinstallationen.
- JS-syntaks er kontrolleret, men ikke gennemtestet i mobilbrowser.
