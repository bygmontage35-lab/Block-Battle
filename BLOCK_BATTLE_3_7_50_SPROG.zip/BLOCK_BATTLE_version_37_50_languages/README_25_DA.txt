BLOCK BATTLE GOLD EDITION 2.5 – XP & GLOBAL TESTRANGLISTE

XP: Level 0 ved start. Level 1 ved 500 XP. Hvert fulde minut i en onlinekamp giver 100 XP (max 3 minutter i klassisk kamp, max 10 minutter i Royale). En delvis minut giver ikke XP. Vundne/tabte kampe registreres stadig.
VERDENSRANGLISTE: Visning af spillere forbundet til samme online testserver. Rang, land, level, XP og sejre. Data ligger i serverens RAM og slettes ved genstart. Spillere rapporterer selv XP – ikke snydesikkert. Før global lancering kræves database, sikre konti og serverberegnet XP.
BETALINGER: Kun en markeret 'kommer senere'-sektion. INGEN rigtige køb kan foretages. Betalingsleverandør, produktkatalog, backend kvitteringsvalidering, refundering og fair-play regler mangler.
Test i Windows: npm install, npm start, åbn http://localhost:3000. For global adgang skal serveren deployeres.
