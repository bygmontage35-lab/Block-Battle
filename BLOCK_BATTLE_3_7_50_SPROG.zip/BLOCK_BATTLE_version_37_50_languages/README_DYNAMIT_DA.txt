BLOCK BATTLE 1.9 – DYNAMIT OG BAGGRUNDE

- Ved hver ny kamp vælges en anden automatisk spillepladebaggrund blandt 7 temaer.
- Spilleren kan fortsat vælge en bestemt baggrund under Indstillinger; det valg respekteres.
- Baggrunden skifter ikke længere hvert 12. sekund under spillet.
- Ryd 4 vandrette rækker for første dynamit.
- Klik på RYD PLADEN for at fjerne alle placerede brikker.
- Behold point, niveau, aktiv brik og tilbageværende kamptid.
- Næste dynamit kræver 7 rækker, derefter 10, 13 osv.
- Du kan højst have én ubrugt dynamit ad gangen.
- Dynamit påvirker kun din egen spilleplade, ikke modstanderens.
- Ved en ny kamp nulstilles dynamitprogressionen.

OBS: Multiplayer er stadig en testudgave, og serveren skal hostes for onlinekampe.
