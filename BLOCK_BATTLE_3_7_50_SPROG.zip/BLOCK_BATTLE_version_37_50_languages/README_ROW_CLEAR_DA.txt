BLOCK BATTLE 1.6

NYT: Når en vandret række er helt fyldt, fjernes den. Alle rækker ovenover rykker ned. Flere fyldte rækker fjernes samtidigt. Der gives point for hver række og bonus for flere på én gang.

Lodrette kolonner ryddes ikke længere, så mekanikken svarer til et klassisk faldende blokspil.

Versionen indeholder fortsat app-projekt og online-server fra version 1.5. Online multiplayer kræver fortsat offentlig server og test på flere enheder.
