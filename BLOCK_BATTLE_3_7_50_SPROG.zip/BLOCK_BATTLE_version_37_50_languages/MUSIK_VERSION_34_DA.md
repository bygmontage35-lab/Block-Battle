# BLOCK BATTLE 3.4 – automatisk musik

Musikken er slået til som standard (Obsidian Pulse). Browseren forsøger at starte ved åbning.
Af hensyn til browseres autoplay-politik kan lyd først høres efter første tryk/tastetryk.

Nederst til venstre: 🎵/🔇 skifter mellem afspil og pause, ⚙ åbner musikindstillinger.
Vælg en af 10 originale melodier, eller sluk helt; vælg lydstyrke.
Melodivalg og lydstyrke gemmes lokalt. Når du slukker i indstillinger, forbliver den slukket ved næste besøg.

Bemærk: Musikken er ikke testet i en rigtig mobilbrowser endnu.
