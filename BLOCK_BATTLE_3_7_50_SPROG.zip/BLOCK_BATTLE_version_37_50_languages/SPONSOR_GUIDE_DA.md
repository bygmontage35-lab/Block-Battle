# Sponsorpladser – BLOCK BATTLE 3.1

Der er oprettet **60 reserverede annoncepladser** i `sponsor_slots.json`:
- SP-001 til SP-040: direkte sponsorer.
- SP-041 til SP-052: kampagner og events.
- SP-053 til SP-060: reserveret til eventuelle Google Ads-placeringer.

I spillet findes en Sponsorhal, som viser alle 60 pladser, og eksisterende placeholder-pladser på forside og rangliste. Dette er **ikke 60 samtidige reklamer på skærmen**. Det er en oversigt over aftaler/placeringer. Alle er tomme.

## Før lancering
1. Opret offentlig hjemmeside og aftalevilkår, priser, kontaktperson, fakturering, start-/slutdato og visningsregler for hver sponsor.
2. Implementér et sikkert adminpanel og en database til sponsorer, frem for at redigere klientfiler manuelt.
3. Vis tydelig mærkning som 'Annonce' eller 'Sponsoreret' på aktive placeringer.
4. Undgå annoncer over spilkontroller og i kritiske kampøjeblikke; begræns visninger pr. session.
5. Ved Google AdSense: ansøg om godkendelse, følg Googles politikker, kontrollér krav til spil/aldersgrupper, privatlivspolitik og cookie-/samtykkekrav. Brug kun godkendte annonceenheder.
6. Google Ads er annoncørplatformen; Google AdSense er typisk den relevante løsning til at vise Google-annoncer på en hjemmeside.
7. Test mobil, ydeevne og tilgængelighed. Ingen sponsor må kunne injicere HTML eller JavaScript.

**Ikke implementeret:** reelle sponsoraftaler, automatisk annoncerotation, AdSense, analytics, annoncevisninger, betalinger eller fakturering. Ingen tredjepartssporing er indsat.
