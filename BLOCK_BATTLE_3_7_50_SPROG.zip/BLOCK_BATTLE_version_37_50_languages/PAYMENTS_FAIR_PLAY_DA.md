# BLOCK BATTLE 2.6 – betalings- og fair-play-plan

## Hvad version 2.6 indeholder
En tydelig sektion med planlagte kampfordele i alle onlinekampe inklusive rangkampe.
Købsknappen er slået fra. Ingen penge opkræves. Ingen betalingsoplysninger indsamles.

## Fair-play regler, som skal implementeres og testes før lancering
- Betalte kampfordele er tilladt i rangkampe, men begge sider får besked før kampen.
- Højst én betalt fordel pr. spiller pr. kamp. Ingen køb, der kan gentages midt i samme kamp.
- Angreb er spærret de første 30 sekunder.
- Maksimalt 3 sekunders negativ effekt; ingen angreb må forhindre bevægelse indtil eliminering.
- Hver spiller har samme adgang til optjente gratis forsvarsmuligheder.
- Angreb, betaling, inventar og forbrug af varer valideres af serveren.
- Matchhistorik gemmer, om betalte fordele blev brugt, så ranglisten kan revideres.
- Brugere skal kunne rapportere snyd og fejl; logning skal være dataminimeret.
- Tilbyd en separat filtreret rangliste uden køb, hvis balancen viser sig unfair.

## Sikker betalingsarkitektur – endnu IKKE implementeret
1. Opret rigtige brugerkonti og sikker database (fx Supabase Auth + Postgres).
2. Definér produkter på serveren med pris, region, begrænsninger og entydigt produkt-ID.
3. Til Android/iOS-distribution af digitale fordele: undersøg og implementér platformens
   krævede in-app-købssystem (Google Play Billing / Apple In-App Purchase).
   Til browser: en egnet betalingsudbyder som Stripe Checkout, hvis tilladt.
4. Opret køb på serveren; klienten må aldrig selv fastsætte beløb eller tildele varer.
5. Verificér betaling via server-side webhook / app-store kvittering, signatur, ordre-ID
   og idempotens. Brug HTTPS. Opbevar ingen rå kortoplysninger.
6. Tildel varen i en transaktion i databasen; forbrug den atomisk på serveren.
7. Håndter afbrudte køb, refundering, chargebacks, fortrydelse og kundeservice.
8. Indfør aldershensyn, tydelige priser, lokale skatter og GDPR-oplysninger.
9. Test med betalingsudbyderens sandbox og rigtige enheder før produktion.

## Vigtige eksisterende begrænsninger
Serveren har stadig in-memory rum, klientrapporterede scores/XP og ingen sikker login.
Der er ikke en ægte verdensrangliste. 5/10-spillerkampe er ikke stresstestet.
Ingen reelle køb eller varer er aktive i version 2.6.

## Sådan prøver du spillet
Udpak ZIP. På Windows med Node.js: `npm install`, `npm start`.
Åbn `http://localhost:3000`. Online deling kræver serverdeployment.
