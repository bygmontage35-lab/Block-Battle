BLOCK BATTLE 2.1 – EKSTRA LIV OG KAMPCHAT

❤️ Ekstra liv kan købes for 100 TESTmønter. Det aktiveres automatisk når pladen fyldes, eller manuelt under en aktiv kamp. Det rydder kun egen plade og bevarer score og kamptid. Købet gemmes lokalt på enheden.
💬 Kampchat findes under Multiplayer. Beskeder sendes kun til spillere i samme serverrum. Maks. 160 tegn, maks. cirka én besked per 1,2 sekunder. Ingen chat-historik gemmes på serveren.
🛍️ Testbutikken har dynamit, ekstra række og ekstra liv. Ingen rigtige penge trækkes.

VIGTIGT: Chatten har endnu ikke anmeldelse, blokering, aldersbeskyttelse eller moderation. Slå chat fra eller tilføj disse før offentlig lancering. Butik, liv, XP og angreb kræver servervalidering for at forhindre snyd. Ingen rigtig betalingsintegration.

For at dele spillet med andre skal serveren stadig deployeres online. Funktionerne er syntakskontrolleret, men ikke testet på to rigtige telefoner.
