BLOCK BATTLE 1.5 – WEB + ANDROID-APP PROJEKT

HVAD ER KLAR?
Spillet er pakket med en Capacitor-konfiguration til Android.
Webversion og Node.js WebSocket-server ligger i samme projekt.
I Indstillinger findes et felt til serverens HTTPS-adresse, så appen kan forbinde til multiplayer.

1. TEST PÅ DIN COMPUTER
Installer Node.js 20+.
Åbn terminalen i projektmappen.
Kør: npm install
Kør: npm start
Åbn: http://localhost:3000
Åbn adressen i to browsere, opret forskellige profiler, og prøv 1v1.
Serveren skal være startet hele tiden under testen.

2. LÆG SERVEREN ONLINE
Opret et GitHub-repository med indholdet af denne mappe.
Forbind repository til en Render Web Service med render.yaml.
Vent til Render viser din offentlige HTTPS-adresse.
Åbn adressen i to telefonbrowsere og test matchmaking.
NB: Dette kan ikke gøres automatisk uden adgang til dine konti.

3. KLARGØR ANDROID-APPEN
Installer Android Studio og Android SDK på en computer.
Kør i projektmappen:
  npm install
  npm run android:init
  npm run android:sync
  npm run android:open
Android Studio åbner projektet. Tilslut en Android-telefon og tryk Run.
Du kan også bygge en debug-APK i Android Studio.
FØR multiplayer på telefonen: Åbn Indstillinger og gem din Render HTTPS-serveradresse.
Der er ikke medsendt en færdig APK, fordi Android SDK og bygningen ikke er kørt her.

4. IPHONE
Capacitor kan også bruges til iOS, men det kræver Mac, Xcode og iOS-platformen:
  npm install @capacitor/ios
  npx cap add ios
  npx cap sync ios
  npx cap open ios
iPhone-build og App Store-udgivelse er IKKE gennemført.

BEGRÆNSNINGER
Dette er en tidlig testudgave, ikke en færdig app til offentlig udgivelse.
Serveren bruger midlertidige rum i RAM, ikke en database.
Spillernavn er ikke et sikkert login. Point kan manipuleres af klienter.
Google Play-login, reklameintegration, privatlivspolitik, billedmoderation og betalinger mangler.
Holdopdeling og vindere skal stadig gennemtestes med 4-6 rigtige spillere.
Appen skal testes på fysiske enheder. Ingen onlineadresse eller APK er udstedt.
